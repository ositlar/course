import org.apache.poi.xssf.usermodel.XSSFWorkbook
import org.jsoup.Jsoup
import org.litote.kmongo.getCollection
import org.jsoup.Jsoup.*
import java.io.FileReader
import java.io.Reader
import javax.xml.stream.XMLInputFactory

fun main() {
    val route = "C:/Users/Максим/Desktop/course/src/main/resources/35.html"
    val file = FileReader(route).readText()
    val htmlTable = Jsoup.parse(file)
    val controller = htmlController_v2(htmlTable)

    val mongo = mongoDatabase.getCollection<Group>().apply { drop() }
    mongo.insertMany(controller.group)
    prettyPrintCursor(mongo.find())

}
