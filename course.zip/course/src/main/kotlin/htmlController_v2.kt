import org.jsoup.nodes.Document

class htmlController_v2 (
    file: Document
        ) {
    val table = file.select("table")
    val group = collecting(file)

    fun collecting (file: Document): MutableList<Group> {
        val result: MutableList<Group> = mutableListOf()
        val temp: Group =
            Group("20з", tableAnalysis(file))
        result.add(temp)
        return result
    }

    fun tableAnalysis (file: Document): TimeTable {
        val timeTable = TimeTable(mutableListOf(), mutableListOf())
        var currentLesson: Lesson?
        val table = file.select("table")
        var upperWeekDay: Day
        var lowerWeekDay: Day
        for (rowIter in 2 until table.select("tr").size-1) {
            upperWeekDay = Day (
                table.select("tr")[rowIter].select("td")[0].text(),
                mutableListOf()
                    )
            lowerWeekDay = Day (
                table.select("tr")[rowIter].select("td")[0].text(),
                mutableListOf()
                    )
            for (coll in 1..6) {
                val cell = table.select("tr")[rowIter].select("td")
                if (cell[coll].text().filter { !it.isWhitespace() } != "") {
                    val one = cell[coll].text().split("ст.пр")
                    val two = cell[coll].text().split("доц.")
                    val three = cell[coll].text().split("проф.")
                    val PE = cell[coll].text().contains("Физкультура", ignoreCase = true)
                    if (!PE) {
                        if ((one.size == 1) && (three.size == 1)) {
                            currentLesson = Lesson(
                                cell[coll].text().substringBefore("."),
                                cell[coll].text().substringAfter("доц.").substringBefore("а."),
                                cell[coll].text().substringBefore("доц.").substringAfter(".")
                                    .substringBefore("- 1").substringBefore("-2"),
                                cell[coll].text().substringAfter("а.")
                            )
                        } else if ((one.size == 1) && (two.size == 1)) {
                            currentLesson = Lesson(
                                cell[coll].text().substringBefore("."),
                                cell[coll].text().substringAfter("ст.пр.").substringBefore("а."),
                                cell[coll].text().substringBefore("проф.").substringAfter(".")
                                    .substringBefore("- 1").substringBefore("-2"),
                                cell[coll].text().substringAfter("а.")
                            )
                        } else {
                            currentLesson = Lesson(
                                cell[coll].text().substringBefore("."),
                                cell[coll].text().substringAfter("ст.пр.").substringBefore("а."),
                                cell[coll].text().substringBefore("ст.пр.").substringAfter(".")
                                    .substringBefore("- 1").substringBefore("-2"),
                                cell[coll].text().substringAfter("а.")
                            )
                        }
                    } else {
                        currentLesson = Lesson(
                            "пр.",
                        "-",
                            cell[coll].text().substringBefore("a."),
                            cell[coll].text().substringAfter("a.")
                        )
                    }
                } else {
                    currentLesson = null
                }
                if ((table.select("tr").size-1 - rowIter) >= 6) {
                    upperWeekDay.classes.add(currentLesson)
                } else {
                    lowerWeekDay.classes.add(currentLesson)
                }
            }
            timeTable.upperWeek.add(upperWeekDay)
            timeTable.lowerWeek.add(lowerWeekDay)
        }
        return timeTable
    }
}