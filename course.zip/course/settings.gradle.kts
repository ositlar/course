
rootProject.name = "hellomaks_kurs2"

